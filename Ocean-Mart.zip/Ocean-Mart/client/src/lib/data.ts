import salmonImage from '@assets/generated_images/salmon_fillet.png';
import lobsterImage from '@assets/generated_images/fresh_lobster.png';
import oystersImage from '@assets/generated_images/oysters_on_ice.png';
import shrimpImage from '@assets/generated_images/jumbo_shrimp.png';

export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
}

export interface NewsArticle {
  id: number;
  title: string;
  date: string;
  excerpt: string;
  content: string;
  image: string;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Premium Atlantic Salmon",
    price: 24.99,
    description: "Sustainably sourced Atlantic salmon, rich in Omega-3s and perfect for grilling or sushi.",
    image: salmonImage,
    category: "Fish"
  },
  {
    id: 2,
    name: "Live Maine Lobster",
    price: 45.00,
    description: "Wild-caught Maine lobster, delivered live to ensure the freshest taste possible.",
    image: lobsterImage,
    category: "Shellfish"
  },
  {
    id: 3,
    name: "Fresh Pacific Oysters (Dozen)",
    price: 32.50,
    description: "Plump and briny Pacific oysters, perfect for serving raw on the half shell.",
    image: oystersImage,
    category: "Shellfish"
  },
  {
    id: 4,
    name: "Jumbo Tiger Shrimp",
    price: 28.99,
    description: "Large, succulent tiger shrimp. Ideal for cocktails, scampi, or grilling.",
    image: shrimpImage,
    category: "Shellfish"
  }
];

export const news: NewsArticle[] = [
  {
    id: 1,
    title: "Sustainable Fishing Practices: Our Commitment",
    date: "2023-10-15",
    excerpt: "Learn how we ensure that our ocean's bounty is preserved for future generations through responsible sourcing.",
    content: "At Ocean Catch, sustainability isn't just a buzzword; it's the core of our business. We work directly with fishermen who use line-caught methods to minimize bycatch and protect the ocean floor. Our commitment extends to...",
    image: "https://images.unsplash.com/photo-1534951009808-766178b47a8e?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "5 Best Recipes for Summer Grilling",
    date: "2023-09-22",
    excerpt: "Fire up the grill! We've curated the top 5 seafood recipes that are perfect for your next backyard barbecue.",
    content: "Summer is here, and there's nothing better than the smell of grilled seafood. From cedar-plank salmon to garlic butter shrimp skewers, here are our top picks...",
    image: "https://images.unsplash.com/photo-1623961990059-2843770d9970?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "The Health Benefits of Omega-3s",
    date: "2023-08-10",
    excerpt: "Discover why seafood is an essential part of a healthy diet and how Omega-3 fatty acids support heart health.",
    content: "Omega-3 fatty acids are essential nutrients that our bodies cannot produce on their own. They are abundant in fatty fish like salmon, mackerel, and sardines...",
    image: "https://images.unsplash.com/photo-1615141982880-13f55e3ce603?q=80&w=2070&auto=format&fit=crop"
  }
];
