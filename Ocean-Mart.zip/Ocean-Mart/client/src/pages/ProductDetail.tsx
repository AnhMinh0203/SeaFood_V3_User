import { products } from "@/lib/data";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-context";
import { useToast } from "@/hooks/use-toast";
import { Minus, Plus, ShoppingCart, Truck, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const product = products.find(p => p.id === Number(params?.id));
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="container px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Product not found</h1>
        <Link href="/">
          <Button>Return Home</Button>
        </Link>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    toast({
      title: "Added to cart",
      description: `Added ${quantity} ${product.name} to your cart.`,
    });
  };

  return (
    <div className="container px-4 py-12 md:py-20 min-h-screen">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20">
        {/* Product Image */}
        <div className="bg-muted rounded-xl overflow-hidden aspect-square sticky top-24">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Product Info */}
        <div className="flex flex-col justify-center">
          <span className="text-sm font-medium text-primary uppercase tracking-widest mb-4">
            {product.category}
          </span>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-foreground">
            {product.name}
          </h1>
          <div className="text-3xl font-bold text-primary mb-8">
            ${product.price.toFixed(2)}
          </div>
          
          <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
            {product.description}
          </p>

          <div className="flex items-center gap-6 mb-10">
            <div className="flex items-center border rounded-md">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="h-12 w-12 rounded-none"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center font-medium text-lg">{quantity}</span>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setQuantity(quantity + 1)}
                className="h-12 w-12 rounded-none"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <Button size="lg" className="flex-1 h-12 text-base" onClick={handleAddToCart}>
              <ShoppingCart className="mr-2 h-5 w-5" /> Add to Cart
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8 border-t">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Truck className="h-5 w-5 text-primary" />
              <span>Next day delivery available</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <ShieldCheck className="h-5 w-5 text-primary" />
              <span>Quality guarantee</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
