import heroImage from '@assets/generated_images/seafood_hero_image.png';
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/product-card";
import { products } from "@/lib/data";
import { Link } from "wouter";
import { ArrowRight, Star, Truck, ShieldCheck, Leaf } from "lucide-react";

export default function Home() {
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="Fresh Seafood Display" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        
        <div className="relative z-10 container px-4 text-center text-white">
          <span className="inline-block py-1 px-3 rounded-full bg-primary/80 backdrop-blur-sm text-sm font-medium mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            Premium Quality Seafood
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold mb-6 tracking-tight animate-in fade-in slide-in-from-bottom-5 duration-700 delay-100">
            Taste the Ocean's Finest
          </h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8 text-white/90 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-200">
            Sustainably sourced, expertly handled, and delivered fresh to your doorstep within 24 hours.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <Link href="/news">
               <Button size="lg" className="bg-primary hover:bg-primary/90 text-white min-w-[160px] h-12 text-base">
                Shop Now
              </Button>
            </Link>
            <Link href="/news">
               <Button size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm border-white/40 text-white hover:bg-white/20 min-w-[160px] h-12 text-base">
                Our Story
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/30">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
                <Truck className="h-6 w-6" />
              </div>
              <h3 className="font-serif font-bold text-xl mb-2">Fast Delivery</h3>
              <p className="text-muted-foreground">From the dock to your door in 24 hours or less, guaranteed.</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/30">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="font-serif font-bold text-xl mb-2">Quality Certified</h3>
              <p className="text-muted-foreground">Every catch is inspected by our experts to ensure premium quality.</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/30">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
                <Leaf className="h-6 w-6" />
              </div>
              <h3 className="font-serif font-bold text-xl mb-2">Sustainable Sourcing</h3>
              <p className="text-muted-foreground">We partner with fisheries committed to protecting our oceans.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-muted/20">
        <div className="container px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Fresh Arrivals</h2>
              <p className="text-muted-foreground max-w-lg">
                Our latest catch, straight from the boat. Get them before they're gone.
              </p>
            </div>
            <Link href="/news"> {/* Ideally this goes to a shop page but we'll use news/shop interchangeably for prototype simplicity or link to section */}
              <Button variant="ghost" className="hidden sm:flex group">
                View All <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="mt-8 text-center sm:hidden">
            <Link href="/news">
              <Button variant="ghost" className="group">
                View All <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="1"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')` }}></div>
        <div className="container px-4 relative z-10 text-center">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6">Join the Ocean Club</h2>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto mb-10 text-lg">
            Get exclusive access to limited-time catches, chef recipes, and 10% off your first order.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex h-12 w-full rounded-md border border-white/20 bg-white/10 px-4 py-2 text-sm text-white placeholder:text-white/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 disabled:cursor-not-allowed disabled:opacity-50"
            />
            <Button size="lg" variant="secondary" className="h-12 px-8 font-semibold">
              Subscribe
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
