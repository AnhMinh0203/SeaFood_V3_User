import { news } from "@/lib/data";
import { NewsCard } from "@/components/ui/news-card";
import { Separator } from "@/components/ui/separator";

export default function News() {
  return (
    <div className="container px-4 py-12 md:py-20 min-h-screen">
      <div className="max-w-3xl mx-auto text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Ocean Journal</h1>
        <p className="text-lg text-muted-foreground">
          Stories from the sea, sustainable practices, and culinary inspiration for your kitchen.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {news.map(article => (
          <NewsCard key={article.id} article={article} />
        ))}
      </div>
    </div>
  );
}
