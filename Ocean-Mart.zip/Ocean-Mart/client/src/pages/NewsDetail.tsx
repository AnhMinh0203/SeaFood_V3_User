import { news } from "@/lib/data";
import { useRoute } from "wouter";
import { CommentSection } from "@/components/ui/comment-section";
import { CalendarDays, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function NewsDetail() {
  const [, params] = useRoute("/news/:id");
  const article = news.find(n => n.id === Number(params?.id));

  if (!article) {
    return (
      <div className="container px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Article not found</h1>
        <Link href="/news">
          <Button>Back to News</Button>
        </Link>
      </div>
    );
  }

  return (
    <article className="min-h-screen pb-20">
      <div className="w-full h-[50vh] relative overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full p-8 md:p-16 text-white">
          <div className="container px-4">
            <Link href="/news">
              <Button variant="link" className="text-white/80 hover:text-white p-0 mb-6">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to News
              </Button>
            </Link>
            <h1 className="text-3xl md:text-5xl font-serif font-bold mb-4 max-w-4xl">
              {article.title}
            </h1>
            <div className="flex items-center text-white/80">
              <CalendarDays className="h-4 w-4 mr-2" />
              {format(new Date(article.date), "MMMM d, yyyy")}
            </div>
          </div>
        </div>
      </div>
      
      <div className="container px-4 py-12 max-w-3xl mx-auto">
        <div className="prose prose-lg dark:prose-invert max-w-none font-serif leading-relaxed">
          <p className="text-xl text-muted-foreground font-sans mb-8 leading-relaxed">
            {article.excerpt}
          </p>
          <p>{article.content}</p>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </p>
          <p>
            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </div>
        
        <div className="mt-16 pt-8 border-t">
          <CommentSection />
        </div>
      </div>
    </article>
  );
}
