import { NewsArticle } from "@/lib/data";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { CalendarDays, ArrowRight } from "lucide-react";
import { format } from "date-fns";

export function NewsCard({ article }: { article: NewsArticle }) {
  return (
    <Link href={`/news/${article.id}`}>
      <Card className="group overflow-hidden cursor-pointer h-full border-none shadow-sm hover:shadow-md transition-shadow flex flex-col">
        <div className="aspect-[16/9] relative overflow-hidden bg-muted">
          <img 
            src={article.image} 
            alt={article.title}
            className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105" 
          />
        </div>
        <CardContent className="p-6 flex flex-col flex-grow">
          <div className="flex items-center text-xs text-muted-foreground mb-3">
            <CalendarDays className="h-3 w-3 mr-1" />
            {format(new Date(article.date), "MMMM d, yyyy")}
          </div>
          <h3 className="font-serif font-bold text-xl mb-3 leading-tight group-hover:text-primary transition-colors">
            {article.title}
          </h3>
          <p className="text-muted-foreground text-sm line-clamp-3 mb-4 flex-grow">
            {article.excerpt}
          </p>
          <div className="flex items-center text-primary text-sm font-medium mt-auto group-hover:translate-x-1 transition-transform">
            Read Article <ArrowRight className="ml-1 h-3 w-3" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
