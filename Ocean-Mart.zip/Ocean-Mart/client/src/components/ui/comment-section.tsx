import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

interface Comment {
  id: number;
  author: string;
  avatar: string;
  text: string;
  date: Date;
}

export function CommentSection() {
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      author: "Sarah J.",
      avatar: "",
      text: "This is a fantastic initiative! I love knowing where my seafood comes from.",
      date: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    },
    {
      id: 2,
      author: "Mike T.",
      avatar: "",
      text: "Tried the salmon recipe last night, it was delicious.",
      date: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    }
  ]);
  const [newComment, setNewComment] = useState("");
  const [authorName, setAuthorName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !authorName.trim()) return;

    const comment: Comment = {
      id: Date.now(),
      author: authorName,
      avatar: "",
      text: newComment,
      date: new Date(),
    };

    setComments([comment, ...comments]);
    setNewComment("");
    setAuthorName("");
  };

  return (
    <div className="mt-12">
      <h3 className="text-2xl font-serif font-bold mb-6">Comments ({comments.length})</h3>
      
      <form onSubmit={handleSubmit} className="mb-10 bg-muted/30 p-6 rounded-lg">
        <h4 className="font-semibold mb-4">Leave a comment</h4>
        <div className="grid gap-4">
          <Input 
            placeholder="Your Name" 
            value={authorName}
            onChange={(e) => setAuthorName(e.target.value)}
            className="bg-background"
          />
          <Textarea 
            placeholder="Share your thoughts..." 
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="bg-background min-h-[100px]"
          />
          <Button type="submit" className="w-full sm:w-auto">Post Comment</Button>
        </div>
      </form>

      <div className="space-y-6">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-4">
            <Avatar>
              <AvatarImage src={comment.avatar} />
              <AvatarFallback>{comment.author[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-sm">{comment.author}</p>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(comment.date, { addSuffix: true })}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{comment.text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
